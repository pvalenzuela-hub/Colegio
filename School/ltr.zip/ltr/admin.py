from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(Colegio)
admin.site.register(Ticket)
admin.site.register(Seguimiento)
admin.site.register(Area)
admin.site.register(Subarea)
admin.site.register(EstadoTarea)
admin.site.register(Estadoticket)
admin.site.register(Tipocontacto)
admin.site.register(TipoTarea)
admin.site.register(Ciclos)
admin.site.register(ResponsableSuperior)
admin.site.register(ResponsableSubareaCiclo)
admin.site.register(CoordinadorCiclo)
admin.site.register(Personas)
admin.site.register(Nivel)
admin.site.register(Curso)
